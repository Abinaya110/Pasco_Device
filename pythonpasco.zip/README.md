set FLASK_APP=serverpy1.py
flask run --port=7080
echo %FLASK_APP%
$env:FLASK_APP = "serverpy1.py"



python -m virtualenv pasco --no-site-packages
.\pasco\Scripts\activate
pip install package_name --user

python -m pipenv --python "C:\Users\user\AppData\Local\Microsoft\WindowsApps\PythonSoftwareFoundation.Python.3.11_qbz5n2kfra8p0\python.exe"

python -m pipenv --venv
